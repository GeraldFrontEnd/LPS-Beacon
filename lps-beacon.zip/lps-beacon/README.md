# LPS-Beacon

**Resource Planning Forecast Chatbot** — an AI-powered assistant that turns messy project, pipeline, workforce and
financial planning files into headcount forecasts, supply-versus-demand analysis, resource matching, profit and loss
views and monthly forecast reports, all through a natural-language chat interface.

> Upload your planning files, ask questions in plain English, and get cleaned data, forecasts, charts and
> downloadable reports back in the same conversation.

![LPS-Beacon architecture](docs/architecture.svg)

---

## Table of contents

1. [Project status](#project-status)
2. [What the chatbot does](#what-the-chatbot-does)
3. [Capabilities and features](#capabilities-and-features)
4. [Roles and access](#roles-and-access)
5. [Example conversations](#example-conversations)
6. [Architecture](#architecture)
7. [How data flows](#how-data-flows)
8. [Data pipeline: cleaning and standardisation](#data-pipeline-cleaning-and-standardisation)
9. [Forecasting approach](#forecasting-approach)
10. [Triggers](#triggers)
11. [Security and access control](#security-and-access-control)
12. [Data storage layout](#data-storage-layout)
13. [API reference](#api-reference)
14. [Chat history model](#chat-history-model)
15. [Estimated cost](#estimated-cost)
16. [Design decisions](#design-decisions)
17. [Getting started](#getting-started)
18. [Repository layout](#repository-layout)
19. [Data handling](#data-handling)
20. [Known limitations](#known-limitations)
21. [Roadmap](#roadmap)

---

## Project status

This repository currently contains the **web app** and the **design documents**. The AWS backend described below is
designed but not yet in this repository.

| Area | Status | Where |
|---|---|---|
| Sign-in with Amazon Cognito, plus practice accounts for offline work | Implemented | `web/` |
| Role-based navigation and route guards (HR, project manager, finance) | Implemented | `web/` |
| Chat screen (suggested questions, new chat, session ID) | Implemented, answers are mocked until the backend exists | `web/` |
| Upload screen (CSV/Excel up to 20 MB, pre-signed S3 upload, per-file status) | Implemented, mocked until the backend exists | `web/` |
| Dashboard (people needed, assigned and open per project; cost for finance) | Implemented, mock data | `web/` |
| P&L screen (revenue, manpower cost, other costs, profit, margin; finance only) | Implemented, mock data | `web/` |
| Backend contract the web app expects | Documented | [`docs/API_CONTRACT.md`](docs/API_CONTRACT.md) |
| API Lambda, Pipeline Lambda, Bedrock agent, schedules, notifications, infrastructure | Designed | [Architecture](#architecture) |
| Chat history sidebar, charts in chat, what-if scenarios, report downloads | Designed | [Capabilities](#capabilities-and-features) |
| Authenticator-app (TOTP) MFA setup inside the sign-in form | Not supported yet | [Known limitations](#known-limitations) |

---

## What the chatbot does

LPS-Beacon is the single front door for resource planning work. Instead of manually reconciling spreadsheets, a
planner opens the web app, signs in, drops in their files and talks to the assistant.

Behind the chat window, serverless AWS services will:

1. **Receive** the uploaded files (typically 10–12 CSV/XLSX files per batch).
2. **Clean and standardise** them: duplicates, shifted headers, inconsistent names, Excel date serials and wide
   month columns are handled automatically.
3. **Match** demand (quote lines, resource plans, project pipeline) against supply (staff lists, HR headcount,
   utilisation) by grade, month and location.
4. **Forecast** demand, headcount and capacity with statistical models.
5. **Explain** the results with a large language model (Amazon Bedrock) in plain language, including the
   assumptions behind the numbers.
6. **Return** charts, tables, a data-quality report and downloadable reports to the chat, and email a summary when
   scheduled runs finish.

The assistant is the **Resource Planning Forecast Agent**: a Bedrock-hosted Claude model that decides which tool to
call (run a forecast, fetch results, run a what-if) while the numerical work is done by deterministic Python code.
This keeps forecasts repeatable and auditable; the model explains and reasons over the numbers rather than
computing them.

---

## Capabilities and features

The tables below describe the **target design**. See [Project status](#project-status) for what exists today.

### 1. Conversational interface

| Feature | Description |
|---|---|
| Natural-language chat | Ask for forecasts, comparisons, explanations and what-if scenarios in everyday language. |
| Suggested questions | One-click starter questions, tailored to the user's role (only finance sees cost questions). |
| Rich answers | Replies include rendered charts, forecast tables and data-quality summaries, not just text. |
| Chat history sidebar | Every conversation is saved per user and listed newest-first; open any past chat to reload its messages and re-render its charts. |
| Auto-titled chats | The first message generates a short title (for example, "Grade 7 shortfall Q3"). |
| Rename and delete chats | Users manage their own history; chats expire automatically under a configurable retention period. |
| Run references | Answers cite the forecast run they came from, so every number can be traced back. |

### 2. File upload and ingestion

| Feature | Description |
|---|---|
| Batch uploads | Drag and drop 10–12 CSV/XLSX files at once; the batch is treated as one unit of work. |
| Direct-to-storage upload | Files go straight from the browser to S3 using short-lived pre-signed URLs, so large files never pass through the API. |
| Validation before upload | File type (CSV, XLSX, XLS) and size (20 MB each) are checked in the browser and again on the server. |
| Per-file status | Each file shows ready, uploading, done or error, and the queue survives moving between pages. |
| One run per batch | A `manifest.json` written last signals that the batch is complete, so a 12-file upload triggers one pipeline run, not twelve. |
| Duplicate-file detection | Identical files (matched by SHA-256 fingerprint) are skipped. |
| Format-agnostic detection | Sheets and header rows are found by column signature, not by file name or fixed position. |

### 3. Data cleaning and standardisation

The pipeline is built for noisy planning data, including:

- Header rows that are not on row 1, and extra title or "data as of" rows.
- Several small tables side by side on one sheet.
- Wide month layouts (May…March columns plus a fiscal-year column) that need unpivoting to one row per month.
- Excel serial dates, mixed date formats and hidden or zero-width characters in headers.
- Inconsistent naming (for example "Generic 4" and "Generic Resource 4").
- Exact and business-key duplicates, resolved by the latest modified date.
- Leavers, unknown IT codes and missing grades, which are quarantined rather than silently dropped.

Every run produces a **data-quality report** (what was removed, what was quarantined and why) that appears in the
chat and is passed to the model, so the assistant can say "the Grade 7 gap excludes 12 people with a missing grade".

### 4. Forecasting and analysis

| Capability | What you get |
|---|---|
| **Demand forecast** | Monthly resource demand by grade, skill and location from quote lines, resource plans and pipeline data. |
| **Headcount forecast** | Projected headcount requirement by month and quarter. |
| **Resource matching** | Supply-versus-demand comparison by grade, month and city, with the gap and the people or roles driving it. |
| **Capacity analysis** | Capacity and utilisation trends, bench cost shown separately from project cost, and shortfall or surplus highlights. |
| **Baseline and forecast P&L** | Project margin from ABCD revenue less resource cost, with bench cost shown separately, then a forecast P&L with stated assumptions. |
| **Monthly and quarterly forecasts** | Scheduled runs on the latest cleaned data, including a quarter-horizon view. |
| **What-if scenarios** | Change an assumption in chat (add hires, slip a project, change a start date) and get the result as a delta against the baseline. |
| **Stated assumptions** | Forecasts list the assumptions and data limits behind them; thin history is flagged, and synthetic data, where used, is clearly marked. |

### 5. Reports and notifications

| Feature | Description |
|---|---|
| Monthly forecast report | Excel and CSV outputs written to storage for each run (PDF is on the roadmap). |
| In-chat results | The same forecast table and charts, rendered in the conversation. |
| Email notifications | Run complete, shortfall detected, stale-data reminder and failure alerts, sent through Amazon SNS with a link back to the app. |
| Audit trail | Accept, edit and reject actions on a forecast are logged with user and timestamp. |

### 6. Security and administration

- Email and password sign-in through Amazon Cognito, with **required authenticator-app MFA** in the target design.
- Role-based access (HR, project manager, finance), enforced by the backend as well as the screens.
- Per-user data isolation: uploads and chat history are scoped by the verified user ID.
- AWS WAF in front of the app, least-privilege IAM per function, encrypted private buckets and a full CloudTrail
  audit trail.
- Per-user daily chat limit and a monthly spend alert to keep model costs predictable.

---

## Roles and access

The role comes from the user's Cognito group.

| Page | HR | Project manager | Finance |
|---|:---:|:---:|:---:|
| Chat | Yes | Yes | Yes (including cost questions) |
| Dashboard | Yes | Yes | Yes, plus monthly cost per project |
| Upload files | Yes | No | Yes |
| P&L | No | No | Yes |

Upload access for HR and finance is an assumption to confirm; it is set in one place,
`web/src/auth/permissions.ts`. Screen rules are a convenience only. The backend must withhold cost and P&L data from
anyone outside the finance group.

---

## Example conversations

```
You:    Upload complete — 11 files.
Beacon: Cleaned 11 files. Removed 57 duplicate rows and 1 duplicate file, quarantined
        55 records with unknown IT codes. Forecast is ready.

You:    Where are we short on headcount next quarter?
Beacon: Grade 7 is short by 6 FTE in Feb–Mar, mainly driven by two projects starting in
        January. Grades 4–5 are in surplus by 3 FTE. [chart] [table]

You:    What if three Grade 7 hires start in January and Project X slips two months?
Beacon: The Grade 7 gap closes in February instead of April, but bench cost rises by
        about 8% in Q4. Compared with the baseline: [delta chart]

You:    Why did the gap grow in March?
Beacon: Two quote lines (Q-1042, Q-1057) start in March, adding 4 FTE of Grade 7
        demand while three people on the staff list have leave dates before then.

You:    Send me the monthly report.
Beacon: Here is the Excel report for this run. [download]
```

These examples are illustrative. The numbers and project names are not real data.

---

## Architecture

The design is deliberately small: **serverless, pay-per-use, nothing running between requests.**

```mermaid
flowchart TB
  user(["Registered user"]) --> web["Chatbot web app (React SPA)"]
  web -- "1 open app" --> cf["CloudFront + AWS WAF"]
  cf --> s3web[("S3 web bucket (private)")]
  web -- "2 sign in + MFA" --> cog["Amazon Cognito"]
  cf -- "3 /api/*" --> apigw["API Gateway (JWT authorizer)"]
  apigw --> lapi["API Lambda"]
  web -- "4 upload via pre-signed URL" --> s3data[("S3 data bucket")]
  s3data -- "T1 manifest.json event" --> lpipe["Pipeline Lambda (container)"]
  sch["EventBridge Scheduler"] -- "T2/T3 monthly, quarterly" --> lpipe
  lapi -- "T4 what-if" --> lpipe
  lpipe -- "R1 write results" --> s3data
  lapi -- "R2 read results" --> s3data
  lapi <-- "R3 chat prompt / answer" --> br["Amazon Bedrock (Claude)"]
  lpipe <--> br
  lapi <-- "H save / load chats" --> ddb[("DynamoDB chat history")]
  lpipe -- "notify" --> sns["SNS email"]
  sns -- "R5 email summary" --> user
  lapi -- "R4 JSON response" --> apigw
```

The full diagram with every service, the nine pipeline steps and cost tags is in
[`docs/architecture.svg`](docs/architecture.svg). The editable version is
[`docs/architecture.drawio`](docs/architecture.drawio) (open it in [draw.io](https://app.diagrams.net)).

### Components

| Component | Role |
|---|---|
| **Chatbot web app** | React single-page app: chat, history sidebar, file upload, dashboard, P&L. Hosted in a private S3 bucket. |
| **Amazon CloudFront + AWS WAF** | HTTPS entry point for both the app and `/api/*`. WAF filters bad IPs, common exploits and request floods. |
| **Amazon Cognito** | Sign-up, sign-in and required MFA; issues the JWT used on every API call. |
| **API Gateway (HTTP API)** | Routes API calls; the JWT authorizer rejects unauthenticated calls. |
| **API Lambda** | Fast request handler: pre-signed URLs, run status, chat answers, chat history. Takes the user ID only from the verified token. |
| **Pipeline Lambda** | Container-image function (pandas, openpyxl, statsmodels): cleaning, matching, forecasting, report generation. 3 GB, up to 15 minutes, concurrency 1, idempotent by batch ID. |
| **Amazon S3 (data)** | `raw/`, `clean/`, `curated/`, `results/`, `reports/`, `quarantine/` prefixes. Block Public Access on. |
| **Amazon Bedrock** | Claude Haiku 4.5 for chat, Claude Sonnet 4.5 for run narratives. Receives aggregates and summaries, not raw rows. |
| **Amazon DynamoDB** | Chat sessions and messages, run records, what-if scenarios, audit log; on-demand with TTL. |
| **EventBridge Scheduler** | Monthly and quarterly forecast triggers. |
| **Amazon SNS** | Email notifications for completed runs, alerts and failures. |
| **IAM, CloudWatch, CloudTrail, ECR** | Least-privilege roles, logs and alarms, audit trail, container image storage. |

---

## How data flows

Numbers on the architecture diagram map to these steps.

**Requests and uploads**

| Step | What happens |
|---|---|
| 1 | The user opens the app through CloudFront; WAF filters the traffic. |
| 2 | The user signs in with email, password and an authenticator-app code; Cognito returns a JWT. |
| 3 | The app calls `/api/*` with the JWT; API Gateway validates it. |
| 4 | The browser uploads files to `raw/{user_sub}/{batch_id}/` using pre-signed URLs, writing `manifest.json` last. |

**Results back to the user**

| Step | What happens |
|---|---|
| **R1** | The Pipeline Lambda writes `results/{run_id}.json` (forecast table, supply-versus-demand gaps, chart specs, narrative), curated Parquet, reports and the data-quality report to S3. |
| **R2** | The API Lambda reads the latest results for run status, charts and chat context. |
| **R3** | The API Lambda sends the question plus a results summary to Bedrock, which returns the answer. |
| **R4** | The JSON response returns API Lambda → API Gateway → CloudFront → web app, which renders the reply, charts and tables. |
| **R5** | Scheduled runs and alerts email a summary and link through SNS. |

**Chat history**

| Step | What happens |
|---|---|
| **H1** | On page load, `GET /sessions` lists the user's chats from DynamoDB for the sidebar. |
| **H2** | Each `/chat` call saves the question and answer, with any run IDs. |
| **H3** | Opening a past chat reloads its messages and re-renders its charts from `results/`. |

---

## Data pipeline: cleaning and standardisation

The Pipeline Lambda runs these steps in order. For typical batches (a few MB across several files) the whole run
takes seconds to a minute.

| # | Step | What it does |
|---|---|---|
| 1 | **Fingerprint** | SHA-256 per file; identical duplicates are skipped. |
| 2 | **Detect** | Finds the right sheet and header row by column signature. |
| 3 | **Standardise** | Trims text, strips hidden characters, converts headers to snake_case, applies a synonym map. |
| 4 | **Fix types** | Excel serials to dates, grade to integer, "Generic 4" to grade 4. |
| 5 | **Reshape** | Unpivots month columns plus fiscal year into one row per month. |
| 6 | **De-duplicate** | Removes exact duplicates and business-key duplicates; the latest modified date wins. |
| 7 | **Validate** | Leavers, unknown IT codes and missing grades go to `quarantine/` with the reason, and into the data-quality report. |
| 8 | **Match and forecast** | Supply versus demand by grade and month; demand, headcount, capacity and P&L forecasts. |
| 9 | **Publish** | Bedrock summary, curated Parquet, results JSON, Excel/CSV report, then an SNS notification. |

**Why Python in Lambda instead of AWS Glue or Athena?** The data is small, pandas reads `.xlsx` directly, Lambda
starts instantly and costs fractions of a cent per run, and there are no jobs, crawlers or catalog tables to
maintain. Revisit Glue/Athena only if a batch reaches hundreds of megabytes or millions of rows.

### Planning inputs

The workflow joins four kinds of input:

| Input | Typical content | Join key |
|---|---|---|
| **SFDC pipeline** | Opportunities, won/lost status, with or without a quote | Opportunity name |
| **ABCD report** | Project ID, TCV and revenue, start/end dates, opportunity name | Project ID |
| **SL × RP report** | Staff list × resource plan (cost by staff, grade, month), produced from the MSPO quote → quote-line flow | IT code |
| **HC by HR** | HR headcount: active staff, grade, join and leave dates | IT code |

---

## Forecasting approach

- **The model does not do the maths.** Statistical methods (for example Holt-Winters or trend plus seasonality per
  grade) run in Python and produce the same numbers every time.
- **The agent explains and reasons.** Claude receives summaries: data-quality results, historical aggregates,
  forecast values and confidence ranges. It explains drivers, flags anomalies, compares scenarios and answers "why"
  questions.
- **Tool use, not free-form queries.** The agent can only call a fixed set of tools (run forecast, get results, run
  what-if). It never writes arbitrary queries against the data.
- **Honest about limits.** Short history and missing data are reported with the forecast.

---

## Triggers

| ID | Trigger | Runs |
|---|---|---|
| **T1** | `manifest.json` lands in `raw/` after an upload batch | Clean, match, forecast on the new batch |
| **T2** | Monthly schedule (3rd of each month, 09:00 SGT) | Forecast on the latest curated data; reminds the team if data is stale |
| **T3** | Quarterly schedule (after fiscal-quarter close) | Quarter-horizon forecast and headcount matching report |
| **T4** | User asks in chat to re-run or try a what-if | Scenario forecast against the baseline |

Reserved concurrency of 1 prevents overlapping runs, and idempotency by batch ID makes duplicate S3 events harmless.
A failed run emails an administrator instead of failing silently. The quarterly schedule assumes an April–March
fiscal year; confirm this before building the schedule.

---

## Security and access control

| Layer | Control |
|---|---|
| **Identity** | Cognito user pool, email + password, **required authenticator-app (TOTP) MFA**; self sign-up can be disabled for invite-only use. Groups `hr`, `pm`, `finance`. |
| **API** | JWT authorizer on every route; issuer and audience pinned to this user pool and app client. |
| **Edge** | AWS WAF on CloudFront: managed core rule set, IP reputation list and a per-IP rate limit; Shield Standard DDoS protection included. |
| **Uploads** | Pre-signed URLs expire in about 5 minutes, scoped to `raw/{user_sub}/`; file type and size validated before issuing. |
| **Data** | Private buckets, Block Public Access, TLS-only bucket policy, default encryption; raw uploads auto-expire after 30 days. |
| **Isolation** | The API Lambda derives the user ID from the verified JWT only, never from the request body. |
| **Least privilege** | One IAM role per function; only the API Lambda touches the chat table. |
| **AI safety** | Fixed tool set, server-side system prompt, aggregates instead of raw rows sent to the model. |
| **Input safety** | Cells are read as values (never evaluated as formulas); leading `=`, `+`, `-`, `@` are neutralised in any export. |
| **Audit** | CloudTrail for API and S3 data events; accept/edit/reject actions logged with user and time. |
| **Cost guardrails** | Per-user daily chat cap and an AWS Budgets alert. |

**CORS:** uploads go cross-origin from the app's CloudFront domain to S3, so the data bucket needs a CORS rule that
allows `PUT`/`GET`/`HEAD` from your exact app origin. The API itself is same-origin when served through CloudFront.

---

## Data storage layout

```
s3://<data-bucket>/
├── raw/{user_sub}/{batch_id}/        # original uploads + manifest.json (expires after 30 days)
├── clean/                            # standardised table per source (Parquet)
├── curated/                          # joined supply-vs-demand tables (Parquet)
├── results/{run_id}.json             # forecast table, gaps, chart specs, narrative, DQ summary
├── reports/{run_id}/                 # monthly forecast report (Excel / CSV)
└── quarantine/{batch_id}/            # rejected rows with reasons
```

---

## API reference

All routes require a valid Cognito JWT (`Authorization` header).

### Used by the web app today

Defined in [`docs/API_CONTRACT.md`](docs/API_CONTRACT.md) and implemented in `web/src/api/client.ts`.

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/chat` | Send `{ sessionId, message }`; returns `{ reply }` |
| `POST` | `/upload-url` | Send `{ fileName, contentType }`; returns a pre-signed `{ uploadUrl, key }` |
| `GET` | `/dashboard` | Project staffing summary; cost fields only for finance |
| `GET` | `/pnl` | Profit and loss rows; finance only (`403` otherwise) |

### Planned additions

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/upload-urls` | Batch version: validate a file list and return URLs for the whole batch |
| `POST` | `/runs` | Start a run (re-run or what-if) and return a run ID |
| `GET` | `/runs/{id}` | Run status and results |
| `GET` | `/sessions` | List the signed-in user's chats |
| `POST` | `/sessions` | Start a new chat |
| `GET` | `/sessions/{id}/messages` | Load a chat's messages |
| `PATCH` / `DELETE` | `/sessions/{id}` | Rename or delete a chat |

---

## Chat history model

A single on-demand DynamoDB table keyed by the user's Cognito ID:

| Record | Partition key | Sort key | Holds |
|---|---|---|---|
| Session | `USER#{sub}` | `SESSION#{createdAt}#{id}` | Title, timestamps, linked run |
| Message | `SESSION#{id}` | `MSG#{timestamp}` | Role, text, referenced run or chart IDs |
| Run | `USER#{sub}` | `RUN#{id}` | Trigger, status, results path |
| Scenario | `USER#{sub}` | `SCEN#{id}` | Baseline run, parameters, result run |
| Audit event | `RUN#{id}` | `AUDIT#{timestamp}` | Accept / edit / reject, by whom, when |

Putting the timestamp in the session key returns chats newest-first with one query, which is exactly the sidebar
order. Large data stays in S3; DynamoDB holds small records and pointers. Messages carry a TTL for retention.

---

## Estimated cost

Region: `ap-southeast-1` (Singapore). Public list prices; excludes tax, support plan, SMS MFA and a custom domain.
These are estimates for the designed backend; the web app itself costs only a few cents a month to host.

| Service | Usage basis (pilot / growth) | Pilot | Growth |
|---|---|---|---|
| Bedrock, Haiku 4.5 chat | 600 / 6,000 messages × 6k input + 0.5k output tokens | $5.10 | $51.00 |
| Bedrock, Sonnet 4.5 narratives | 20 / 60 runs × 12k input + 1.5k output tokens | $1.20 | $3.50 |
| AWS WAF | Web ACL + 3 rules + requests | $8.05 | $8.30 |
| S3 | 5 / 50 GB + requests | $0.15 | $1.30 |
| ECR | ~1 GB container image | $0.10 | $0.10 |
| API Gateway, DynamoDB, CloudTrail | ~3.5k / 35k API calls; small tables | $0.05 | $0.10 |
| Lambda | Inside the always-free tier | $0 | $0 |
| CloudFront, Cognito, CloudWatch, SNS, Scheduler, Budgets | Inside free tiers | $0 | $0 |
| **Total per month** | | **≈ $14.65** | **≈ $64.30** |

Pilot = 20 users, 30 chats per user, 20 pipeline runs. Growth = 200 users, 6,000 chats, 60 runs.

**Cost notes**
- Bedrock chat is the main variable cost (about $8.50 per extra 1,000 messages); the per-user daily cap is the most
  effective control.
- WAF is the main fixed cost. If your account is eligible for CloudFront flat-rate plans, the Free plan bundles WAF
  and removes that line.
- Attaching a separate regional web ACL to the Cognito user pool (to rate-limit sign-in and sign-up) adds roughly
  $7 per month; it is optional for invite-only pilots.

---

## Design decisions

How this design relates to the original draft architecture:

| Original draft | Current design | Why |
|---|---|---|
| SQS notification queue | S3 event on `manifest.json` | One run per batch of 10–12 files, no queue to manage |
| Upload processing Lambda | API Lambda (pre-signed URLs) + Pipeline Lambda | Browser uploads straight to S3; validation happens before the URL is issued |
| AWS Glue ETL (Lambda) | Pipeline Lambda (pandas) | Data is small; Glue adds startup time, minimum billing and setup |
| Processed S3 buckets | One data bucket with prefixes | Fewer buckets, same stage separation |
| Athena query engine | Parquet read directly in the pipeline | No catalog or query service needed at this scale |
| Forecast Agent Lambda / Bedrock | Forecast module in the Pipeline Lambda + Bedrock narrative | Deterministic maths, LLM explanation |
| Report Generation Lambda | Step 9 of the pipeline (`reports/`) | One fewer function and trigger |
| SNS notification | SNS email | Kept as designed |
| "Chatbot returns user prompt queries" | R1–R5 return path + chat history in DynamoDB | Results, charts and history come back through the same API |

---

## Getting started

### Run the web app locally (works today, no AWS account needed)

Requires Node.js 20 or newer.

```bash
cd web
npm install
cp .env.example .env      # Windows (Command Prompt): copy .env.example .env
npm run dev
```

Sign in with a practice account such as `finance@demo.com` / `demo123`. Details, configuration and deployment are in
[`web/README.md`](web/README.md).

### Connect the web app to real AWS services

1. Create a Cognito user pool with groups `hr`, `pm`, `finance` and a public app client (no secret).
2. In `web/.env`, set `VITE_USE_MOCK_AUTH=false` and the two Cognito values to try real sign-in first.
3. Once the API exists, set `VITE_USE_MOCK=false` and `VITE_API_URL`. The contract is in
   [`docs/API_CONTRACT.md`](docs/API_CONTRACT.md).

### Build the backend (planned)

The backend is not in this repository yet. The intended steps are:

1. Build and push the pipeline container image to ECR.
2. Deploy the stack with your chosen infrastructure-as-code tool (AWS CDK or AWS SAM): Cognito, S3 buckets with CORS
   and Block Public Access, DynamoDB, both Lambdas, API Gateway, EventBridge schedules, SNS, CloudFront and WAF.
3. Enable Bedrock model access for the Claude models in your region.
4. Confirm the SNS email subscription.

Planned backend settings (template only; keep real values out of Git):

```
AWS_REGION=ap-southeast-1
DATA_BUCKET=<data-bucket-name>
WEB_BUCKET=<web-bucket-name>
APP_ORIGIN=https://<your-cloudfront-domain>
CHAT_MODEL_ID=<haiku-model-id>
NARRATIVE_MODEL_ID=<sonnet-model-id>
DAILY_CHAT_LIMIT=100
```

---

## Repository layout

```
lps-beacon/
├── README.md
├── .gitignore                # secrets, planning data, Node, Python, CDK/SAM, editors
├── .gitattributes
├── docs/
│   ├── API_CONTRACT.md       # what the web app expects from the backend
│   ├── architecture.svg      # full architecture diagram
│   └── architecture.drawio   # editable diagram
├── web/                      # React + TypeScript + Vite web app (see web/README.md)
│   ├── src/
│   ├── scripts/deploy.mjs
│   ├── .env.example
│   └── .env.deploy.example
│
│   Planned:
├── lambdas/                  # api/ (zip) and pipeline/ (container image: clean, forecast, publish)
├── infra/                    # CDK or SAM stacks
└── sample-data/anonymised/   # anonymised test files only
```

---

## Data handling

This project processes HR headcount, staff cost and project revenue data.

- **Never commit real planning files.** `.gitignore` blocks `*.xlsx`, `*.xls`, `*.csv` and `*.parquet` everywhere
  except `sample-data/anonymised/`.
- Anonymise before adding a sample: replace names, IT codes, project names and amounts.
- **Never commit `.env` files.** Only `.env.example` and `.env.deploy.example` are tracked.
- Bucket names and CloudFront distribution IDs are read from `web/.env.deploy` at deploy time, not stored in the
  repository.
- If a secret or real data file is committed by mistake, treat it as exposed: rotate the credential and remove the
  file from the whole Git history, not just the latest commit.

---

## Known limitations

- **MFA setup is not supported in the web app's sign-in form.** If the Cognito user pool requires MFA and the user
  has not enrolled an authenticator app, sign-in stops with "An extra sign-in step is required
  (CONTINUE_SIGN_IN_WITH_TOTP_SETUP)". Use Amplify's `<Authenticator>` component or handle the step with
  `confirmSignIn()` before relying on required MFA. See `web/src/auth/authService.ts`.
- Users who must change their temporary password are told to ask an administrator to set a permanent one.
- Chat, upload, dashboard and P&L use mock data until the backend exists.
- Practice accounts (`DEMO_ACCOUNTS`) should be removed before a production release.
- The backend, infrastructure code and tests are not in this repository yet.

---

## Roadmap

- Handle MFA setup and code entry in the sign-in flow.
- Build the API Lambda, Pipeline Lambda and infrastructure code.
- Chat history sidebar, charts in chat and what-if scenarios.
- PDF version of the monthly forecast report.
- Shortfall alerts with configurable thresholds per grade.
- Side-by-side scenario comparison view.
- Regional web ACL on the Cognito user pool for open public sign-up.
- Glue/Athena (or another warehouse) if batches grow beyond what Lambda handles comfortably.
- Bedrock Agents or a Knowledge Base if the assistant needs to cite policy documents and rate cards.

---

## License

No license has been chosen yet. Until one is added, all rights are reserved by the project owner.
